public class Arqueiro extends Personagem{

    public Arqueiro(String nome, double vida, String descricao) {
        super(nome, vida, descricao);
    }
}
