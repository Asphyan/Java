public class Main {
    public static void main(String[] args) {
        LojaVirtual loj = new LojaVirtual();

        loj.cadastro();
        loj.estoqueLivros();
        loj.alugarLivro();
        loj.devolverLivro();
        loj.alugarLivro();
        loj.alugarLivro();

        loj.impLiv();
    }
}
