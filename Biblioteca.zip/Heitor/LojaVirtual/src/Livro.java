public class Livro {

    private String titulo;
    private String autor;
    private int numPaginas;
    private boolean alugel;

    public Livro(String titulo, String autor, int numPaginas, boolean alugel){
        this.titulo = titulo;
        this.autor = autor;
        this.numPaginas = numPaginas;
    }

    public String getTitulo(){
        return titulo;
    }

    public String getAutor(){
        return autor;
    }

    public int getNumPaginas(){
        return numPaginas;
    }
    public boolean getAluguel(){
        return alugel;
    }

    public void setAluguel(boolean alugel){
        this.alugel = alugel;
    }
}
