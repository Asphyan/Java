import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class LojaVirtual {
    int cont = 0;
    List<Livro> liv;
    Scanner scanner = new Scanner(System.in);

    public LojaVirtual(){
        this.liv = new ArrayList<>();
    }

    public void armazenarLivro(String titulo, String autor, int numPaginas, boolean alugel){
        Livro cadLiv = new Livro(titulo, autor, numPaginas, alugel);

        liv.add(cadLiv);

        System.out.println("Livro cadastrado com sucesso!");
    }

    public void cadastro(){
        System.out.print("Informe quantos livros deseja cadastrar: ");
        int quant = scanner.nextInt();
        scanner.nextLine();

        for(int i = 0; i < quant; i++){
            System.out.print("Titulo: ");
            String titulo = scanner.nextLine();

            System.out.print("\nAutor: ");
            String autor = scanner.nextLine();

            System.out.print("\nNúmero de páginas: ");
            int numPaginas = scanner.nextInt();
            scanner.nextLine();

            boolean alugel = false;

            armazenarLivro(titulo, autor, numPaginas, alugel);
        }
    }

    public void devolverLivro(){
        System.out.print("\nInforme o titulo buscado: ");
        String titulo = scanner.nextLine();

        boolean livroAchado = false;
        for(Livro l : liv){
            if(l.getTitulo().equalsIgnoreCase(titulo)){
                livroAchado = true;
                if(l.getAluguel()){
                    System.out.println("_________________________");
                    System.out.println("Titilo: " + l.getTitulo());
                    System.out.println("Autor: " + l.getAutor());
                    System.out.println("Número de páginas: " + l.getNumPaginas());
                    System.out.println("Livro Devolvido!");
                    System.out.print("_________________________");
                    l.setAluguel(false);
                }else{
                    System.out.println("Livro já está alugado!");
                }
            }
        }

        if(!livroAchado){
            System.out.println("Livro não encontrado!");
        }
    }

    public void alugarLivro(){
        System.out.print("\nInforme o titulo buscado: ");
        String titulo = scanner.nextLine();

        boolean livroAchado = false;
        for(Livro l : liv){
            if(l.getTitulo().equalsIgnoreCase(titulo)){
                livroAchado = true;
                if(!l.getAluguel()){
                    System.out.println("_________________________");
                    System.out.println("Titilo: " + l.getTitulo());
                    System.out.println("Autor: " + l.getAutor());
                    System.out.println("Número de páginas: " + l.getNumPaginas());
                    System.out.println("Livro Alugado!");
                    System.out.print("_________________________");
                    l.setAluguel(true);
                }else{
                    System.out.println("Livro já está alugado!");
                }
            }
        }

        if(!livroAchado){
            System.out.println("Livro não encontrado!");
        }
    }

    public void estoqueLivros(){
        for(Livro l : liv){
            if(l.equals(l)){
                cont++;
            }
        }
        System.out.println("Estoque: " + cont);
    }

    public void impLiv(){
        for(Livro l : liv){
            System.out.println("Titulo: " + l.getTitulo());
            System.out.println("Autor: " + l.getAutor());
            System.out.println("Número de páginas: " + l.getNumPaginas());
            System.out.println("Aluguel: " + l.getAluguel());
        }
    }
}
